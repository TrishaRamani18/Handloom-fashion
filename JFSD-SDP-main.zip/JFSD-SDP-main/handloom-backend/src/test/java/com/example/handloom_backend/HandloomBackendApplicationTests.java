package com.example.handloom_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandloomBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
