import React from 'react';

const Logout = () => {
  // You can handle logout functionality here
  return (
    <div>
      <h2>Logout</h2>
      <p>You have been logged out successfully!</p>
    </div>
  );
};

export default Logout;